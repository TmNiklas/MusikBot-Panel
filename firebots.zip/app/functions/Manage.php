<?php

$manage = new Manage();
class Manage extends Controller
{

    public function songName($data)
    {
        try {
            $response = Request::bot($data,'/song')->Title;
        } catch (Exception $e){
            $response = 'Es wird nichts gespielt';
        }

        return ($response);
    }

}