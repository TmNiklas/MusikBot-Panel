<?php

$ticket = new Ticket();

class Ticket extends Controller
{

    public function create($session_token, $title, $priority, $department, $message){
        $db = self::db();
        $SQL = $db->prepare("INSERT INTO `support_tickets`(`user_id`, `title`, `state`, `department`, `priority`) VALUES (?,?,?,?,?)");
        $SQL->execute(array(User::getDataBySession($session_token,'id'), $title, 'open', $department, $priority));
        $ticket_id = $db->lastInsertId();

        $SQL = self::db()->prepare("INSERT INTO `ticket_messages`(`ticket_id`, `user_id`, `message`) VALUES (?,?,?)");
        $SQL->execute(array($ticket_id, User::getDataBySession($session_token,'id'), $message));
    }

    public function answer($ticket_id, $user_id, $message, $last_response = 'customer')
    {
        $SQL = self::db()->prepare("INSERT INTO `ticket_messages`(`ticket_id`, `user_id`, `message`) VALUES (?,?,?)");
        $SQL->execute(array($ticket_id, $user_id, $message));

        $SQL = self::db()->prepare("UPDATE `support_tickets` SET `last_response` = :last_response WHERE `id` = :id");
        $SQL->execute(array(":last_response" => $last_response, ":id" => $ticket_id));
    }

    public function close($ticket_id)
    {
        $SQL = self::db()->prepare("UPDATE `support_tickets` SET `state` = :state WHERE `id` = :id");
        $SQL->execute(array(":state" => 'closed', ":id" => $ticket_id));
    }

    public function open($ticket_id)
    {
        $SQL = self::db()->prepare("UPDATE `support_tickets` SET `state` = :state WHERE `id` = :id");
        $SQL->execute(array(":state" => 'open', ":id" => $ticket_id));
    }

    public function getData($ticket_id, $data)
    {
        $SQL = self::db()->prepare('SELECT * FROM `support_tickets` WHERE `id` = :id');
        $SQL->execute(array(":id" => $ticket_id));
        $response = $SQL->fetch(PDO::FETCH_ASSOC);

        return $response[$data];
    }

    public function getOpen($user_id)
    {
        $SQL = self::db()->prepare('SELECT * FROM `support_tickets` WHERE `user_id` = :user_id AND `state` = "open"');
        $SQL->execute(array(":user_id" => $user_id));

        return $SQL->rowCount();
    }

    public function getTickets($user_id)
    {
        $SQL = self::db()->prepare('SELECT * FROM `support_tickets` WHERE `user_id` = :user_id');
        $SQL->execute(array(":user_id" => $user_id));

        return $SQL->rowCount();
    }

}
?>