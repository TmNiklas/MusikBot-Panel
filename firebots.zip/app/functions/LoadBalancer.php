<?php

$load = new LoadBalancer();

class LoadBalancer extends Controller
{

    public function getData($data)
    {


    }

    public function getNodes($bot_nodes, $data)
    {

        

    }

}