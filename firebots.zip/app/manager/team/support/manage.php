<?php

$error = null;

if(empty($_POST['message'])){
    $error = 'Bitte gebe eine Nachricht ein';
}

if(empty($error)){
    $ticket->answer($ticket_id, $user->getDataBySession($_COOKIE['session_token'],'id'), $_POST['message'],'support');
    $_SESSION['success_msg'] = 'Deine Antwort wurde an den Kunden uebermittelt';
} else {
    $_SESSION['message_msg'] = $error;
}
?>