<?php
$user_id = $_GET['id'];

if(isset($_POST['saveUser'])){
    $error = null;

    if(empty($_POST['username'])){
        $error = 'Bitte gebe einen gültigen Benutzernamen an';
    }

    if(empty($_POST['email'])){
        $error = 'Bitte gebe eine gültige E-Mail an';
    }

    if(empty($_POST['bot_limit'])){
        $error = 'Bitte gebe eine Bot-Limit an';
    }

    if(empty($_POST['state'])){
        $error = 'Bitte gebe wähle einen Status aus';
    }

    if(empty($_POST['role'])){
        $error = 'Bitte gebe wähle einen Rang aus';
    }

    if(empty($error)){

        $user->update($_POST['username'], $_POST['email'], $_POST['bot_limit'], $_POST['state'], $_POST['role'], $user_id);
        $_SESSION['success_msg'] = 'Benutzerdaten wurden gespeichert';

    } else {
        $_SESSION['error_msg'] = $error;
    }
}

if(isset($_POST['changePassword'])){
    $error = null;


    if(empty($_POST['new_password'])){
        $error = 'Bitte gebe dein neues Passwort an';
    }

    if(empty($error) && empty($_POST['repeat_new_password'])){
        $error = 'Bitte wiederhole dein neues Passwort an';
    }


    if(empty($error)){

        $user->updatePassword($_POST['new_password'], $user_id);
        $_SESSION['success_msg'] = 'Das Passwort wurde geändert';

    } else {
        $_SESSION['error_msg'] = $error;
    }
}

if(isset($_POST['loginAsCustomer'])){
    setcookie('old_session_token', $_COOKIE['session_token'],time()+864000,'/');
    setcookie('session_token', $user->getData($user_id,'session_token'),time()+864000,'/');
    die(header('Location: '.$url));
}