<?php
if(isset($_POST['createTicket'])){
    $error = null;

    if(empty($_POST['title'])){
        $error = 'Bitte gebe einen Titel an';
    }

    if(empty($_POST['priority'])){
        $error = 'Bitte wähle eine Priorität';
    }

    if(empty($_POST['department'])){
        $error = 'Bitte wähle eine Abteilung';
    }

    if(empty($_POST['message'])){
        $error = 'Bitte beschreibe dein Anliegen';
    }

    /*if(!($site->validateCSRF($_POST['csrf_token']))){
        $error = 'Ungültige Anfrage bitte versuche es erneut';
    }*/

    if(empty($error)){

        $ticket->create($_COOKIE['session_token'], $_POST['title'], $_POST['priority'], $_POST['department'], $_POST['message']);
        /*$_SESSION['success_msg'] = 'Das Ticket wurde erstellt.';*/
        echo sendSuccess('Das Ticket wurde erfolgerich erstellt.');

    } else {
        $_SESSION['error_msg'] = $error;
    }
}
?>