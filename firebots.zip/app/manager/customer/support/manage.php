<?php

$error = null;

if(empty($_POST['message'])){
    $error = 'Bitte gebe eine Nachricht ein';
}

if($ticket->getData($ticket_id,'state') == 'closed'){
    $error = 'Dieses Ticket ist bereits geschlossen.';
}

if(empty($error)){
    $ticket->answer($ticket_id, $user->getDataBySession($_COOKIE['session_token'],'id'), $_POST['message']);
    $_SESSION['success_msg'] = 'Deine Antwort wurde an das Team übermittelt';
} else {
    $_SESSION['error_msg'] = $error;
}
?>