<?php

$db_host = 'localhost';
$db_name = 'dynamicbots';
$db_username = 'dynamicbots';
$db_password = 'schalkefanS04!!';

$siteName = 'FireBots';

$grecaptchaSiteKey = '6LdIwN4UAAAAAE68v9nkpYMBnyshVk5j9Ub2bbZz';
$grecaptchaSecret = '6LdIwN4UAAAAALL8eQKL3CayNJEizPdFMBYIy18J';

$url = 'https://firebots.dev.bschleyer.de/';
$cdnUrl = $url.'assets/style/';
$picUrl = $url.'assets/images/';

### SEO-Optimierung ###
$meta_author = 'test';
$meta_copyright = 'test';
$meta_keywords = 'test';
$meta_description = 'test';

### Login/Register-Konfigurationen ###
$Login_LogoText = 'FireBots';
$Login_FormularText = 'Login';
$Register_LogoText = 'FireBots';
$register_underLogoText = 'Registrieren';

### Kunden-Betroffen ###
$kunden_kuerzel = 'FB'; // Kunden-ID Kürzel - hier: FB = FireBots

### Footer-Konfigurationen ###
$copyright_left = 'Copyright &copy; 2020'; // Angabe: Copyright &copy; 2000-2020 (Linke Seite des Footers) \\
# Zwischen beiden also: Datum und Name, trennt ein "-" beide Angaben im Quellcode des Footers #
$copyright_name = 'Justin Harth'; // Angabe: FireBots (direktfolgend nachdem Copyright Jahr \\
$footer_right = '<i class="fas fa-cog fa-spin"></i> Version: v0.6.1.3 Alpha'; // Angabe: FireBots | Dein Hosting Provider für leistungsstarke Musikbots (Rechte Seite des Footers) \\

/*
* Rechtliche-Seiten Einstellungen
*/

$project_description = 'Wir sind ein Bot-Hosting, welches sehr viel Wert auf Qualität und Kompetenz legt.'; // Beschreibung des Projektes
$project_nutzung_link = 'firebots.dev.bschleyer.de'; // URL für die Nutzungsbedingungen


### Footer-Linkangabe ###
$twitter_link = 'link_error'; // Twitter-Profil Link mit https
$discord_link = 'https://discord.gg/uhqbdCQ'; // Discord-Server Link mit https

### Footer-Projektangaben ###
// -> Dazugehörigen Angaben vom Impressum
// ### Impressum ###
$imprint_company = 'Björn Schleyer Einzelunternehmen'; // Angabe: in Fall das ein Unternehmen vorliegt
$imprint_name = 'Björn Schleyer'; // Angabe: Verantwortlicher (Vor- und Nachname)
$imprint_street = 'Darler Heide 92'; // Angabe: Straße und Hausnummer
$imprint_postcode = '45891'; // Angabe: Postleitzahl
$imprint_city = 'Gelsenkirchen'; // Angabe: Ort
$imprint_country = 'Deutschland'; // Angabe: Land (Bsp: Deutschland, Österrreich, Schweiz
$imprint_tel_landwahl = '49'; // Angabe der Vorwahl des Landes (Bsp: Deutschland +49)
$imprint_tel = '020951301038'; // Angabe deiner Telefonnummer
$imprint_email = 'mail@bschleyer.de'; // Angabe: E-Mail Adresse

$imprint_datenschutz = 'mail@bschleyer.de'; // Angaben: E-Mail Adresse für Datenschutz(-beauftragter)